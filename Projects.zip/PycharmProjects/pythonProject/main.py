print("Hello World!")
szam1 = 25
szoveg = "25"
szam2 = 10
print(szam1+szam2)
print(szoveg+str(szam1))
print(int(szoveg)+szam1)
beolvas = input("Adj meg egy szöveget!")
print(beolvas)
beolvas2 = input("Adj meg még egy szöveget!")
print(beolvas + " " + beolvas2)
nev = input("Kerlek add meg a neved!")
szulev = int(input("Kerlek add meg a születésed évét!"))
kor = 2024 - szulev
print("Szia " + nev + "! Te " + str(kor) + "éves vagy.")
if (kor<6):
    print("Te valószínű óvodás vagy.")
    print("Te valószínű óvodás vagy.")
if(kor<50):
    print("Te még nem vagy ötven éves.")
else:
    print("Te már legalább 50 éves vagy.")
if(kor<100):
        print("Te még nem élsz 100 éve.")
elif(kor>100):
    print("Te már több mint száz évet éltél.")
else:
    print("Te pontosan 100 éves vagy.")
print("")
print("Ez volt egy alapvizsgás feledat")
name = input("Mi a neved?")
year = int(input("Mikor születtél?"))
age = 2022 - year
if(age < 18):
    print('Szevasz ' + name + "!")
elif(age < 60):
    print('Jó napot ' + name + "!")
else:
    print('Csókolom ' + name + "!")
print("")
name = input("Mi a neved?")
jegyed = int(input("Hanyast kaptál"))
if(jegyed == 1):
    print("Ez nagyon szar eredmény lett!")
if(jegyed == 2):
    print("Ez is elég szar eredmény de valamennyivel jobb.")
if(jegyed == 3):
    print("Ez már valamennyire elfogadható eredmény.")
if(jegyed == 4):
    print("Ez már eléggé jó eredmény.")
if(jegyed == 5):
    print("Ez már gyönyörű eredmény")
else:
    print("Nem jó értéket adott meg.")